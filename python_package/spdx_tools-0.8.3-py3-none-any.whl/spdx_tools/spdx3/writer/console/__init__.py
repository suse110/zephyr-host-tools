# SPDX-FileCopyrightText: 2023 spdx contributors
#
# SPDX-License-Identifier: Apache-2.0
""" This is a temporary package to write the implemented model of spdx_tools.spdx3.0 to console. As soon as
    serialization formats are properly defined this package can be deleted."""
