# SPDX-FileCopyrightText: 2023 spdx contributors
#
# SPDX-License-Identifier: Apache-2.0
DOCUMENT_SPDX_ID = "SPDXRef-DOCUMENT"
