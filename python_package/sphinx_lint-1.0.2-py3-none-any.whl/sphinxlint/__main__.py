import sys

from sphinxlint import cli

if __name__ == "__main__":
    sys.exit(cli.main())
