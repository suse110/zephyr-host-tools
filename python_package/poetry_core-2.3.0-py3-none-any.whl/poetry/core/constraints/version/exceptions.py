from __future__ import annotations


class ParseConstraintError(ValueError):
    pass
