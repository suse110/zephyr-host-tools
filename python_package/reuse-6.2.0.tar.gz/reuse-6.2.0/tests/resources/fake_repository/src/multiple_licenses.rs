// SPDX-FileCopyrightText: 2022 Jane Doe
// SPDX-License-Identifier: GPL-3.0-or-later
// SPDX-License-Identifier: Apache-2.0 OR CC0-1.0 WITH Autoconf-exception-3.0
