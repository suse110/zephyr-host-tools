# SPDX-FileCopyrightText: 2017 Jane Doe
#
# SPDX-License-Identifier: GPL-3.0-or-later WITH Autoconf-exception-3.0
