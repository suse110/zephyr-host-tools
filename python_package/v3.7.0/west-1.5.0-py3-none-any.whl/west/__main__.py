from west.app.main import main

main()
