# Copyright (c) 2020, Nordic Semiconductor ASA

# nothing here
